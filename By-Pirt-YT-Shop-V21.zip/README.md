
## 🚨  **<**لديك مشكلة**>** 🚨 
✈ **Join Discord :** [・ND・Family ツ](https://discord.gg/nezGUjRDeB) 👌 **ادخل الى سرفري لاتمكن من حل مشكلتك**
```
https://discord.gg/nezGUjRDeB
```
## 🚨 By : **<**Pirt YT**>** 🚨
- ✈ **My :** [Discord](https://discord.gg/nezGUjRDeB)
- ✈ **My :** [youtube](https://www.youtube.com/channel/UCejGcNpkzNdoUqHvcVGfCHg/featured)
![see](https://media.discordapp.net/attachments/963889073766957187/969523671246991380/download.jpg)
